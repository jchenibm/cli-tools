'use client';

import { useEffect, useState, useRef, useCallback } from 'react';
import {
  Box,
  Container,
  VStack,
  Text,
  Button,
  Heading,
  Grid,
  GridItem,
  Progress,
  useColorModeValue,
  Accordion,
  AccordionItem,
  AccordionButton,
  AccordionPanel,
  AccordionIcon,
  useToast,
} from '@chakra-ui/react';
import { useRouter } from 'next/navigation';
import { Radar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip,
  Legend,
} from 'chart.js';
import { questions, categories, maturityLevels, recommendations } from '@/data/surveyData';
import type { Result } from '@/types/survey';
import { Session, CategoryScore } from '@/types/survey';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

ChartJS.register(RadialLinearScale, PointElement, LineElement, Filler, Tooltip, Legend);

// 定义评估意见和整体建议
const maturityLevelAssessments: { [key: string]: string } = {
  '初始级': '数字化转型刚刚起步，缺乏明确的战略和规划，各部门之间协作较少，数据利用率较低。建议：首先制定清晰的数字化转型战略，加强各部门之间的协作，并开始收集和利用数据。',
  '探索级': '开始探索数字化转型，制定了初步的战略和规划，部分部门开始尝试数字化应用，但整体效果有限。建议：继续完善数字化转型战略，扩大数字化技术的应用范围，并加强数据分析能力。',
  '发展级': '数字化转型取得一定进展，制定了较为完善的战略和规划，各部门广泛应用数字化技术，数据利用率有所提高。建议：进一步优化数字化流程，提升数据驱动决策的水平，并探索新的数字化商业模式。',
  '领先级': '数字化转型成效显著，形成了全面的数字化战略和规划，各部门深度应用数字化技术，数据驱动决策成为常态。建议：持续创新数字化应用，构建开放的数字化生态系统，并加强风险管理。',
  '卓越级': '数字化转型达到卓越水平，持续创新数字化应用，构建了完善的数字化生态系统，数据价值得到充分挖掘。建议：保持领先地位，不断探索前沿技术，并积极分享数字化转型经验。',
};

export default function Result() {
  const router = useRouter();
  const [result, setResult] = useState<Result | null>(null);
  const [maturityLevel, setMaturityLevel] = useState<string>('');
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);
  const buttonContainerRef = useRef<HTMLDivElement>(null);
  const [sessionData, setSessionData] = useState<Session | null>(null); // 添加状态变量来存储 session 数据
  const toast = useToast(); // 添加 useToast 钩子

  const boxBg = useColorModeValue('white', 'gray.700');
  const textColor = useColorModeValue('gray.700', 'gray.300');
  const headingColor = useColorModeValue('gray.900', 'whiteAlpha.900');
  const accentColor = useColorModeValue('blue.500', 'blue.300');
  const progressColor = useColorModeValue('green.500', 'green.300');

  const backgroundColor = useColorModeValue('white', 'gray.800');

  useEffect(() => {
    const savedSession = localStorage.getItem('survey_session');
    if (!savedSession) {
      router.push('/');
      return;
    }

    const session: Session = JSON.parse(savedSession);
    if (session.status !== 'completed' || !session.answers.length) {
      router.push('/');
      return;
    }

    setSessionData(session); // 将 session 数据存储到状态中
    calculateResult(session);
    // 在计算结果后自动保存报告
    // 注意：这里需要确保 calculateResult 已经设置了 result 和 sessionData 状态
    // 可以在 calculateResult 完成后或者在 result 状态更新后触发保存
    // 为了简化，先尝试在这里直接调用保存逻辑，如果状态未及时更新可能需要调整
    // 更好的做法是监听 result 状态的变化来触发保存
  }, [router]);

  const calculateResult = (session: Session) => {
    const categoryScores: CategoryScore[] = categories.map((category) => {
      const categoryQuestions = questions.filter((q) => q.categoryId === category.id);
      const categoryAnswers = session.answers.filter((a) =>
        categoryQuestions.some((q) => q.id === a.questionId)
      );

      const totalScore = categoryAnswers.reduce((sum, answer) => {
        const question = questions.find((q) => q.id === answer.questionId);
        const option = question?.options.find((o) => o.id === answer.selectedOptionId);
        return sum + (option?.score || 0);
      }, 0);

      return {
        categoryId: category.id,
        score: totalScore / categoryQuestions.length,
      };
    });

    const totalScore = categoryScores.reduce((sum, cs) => sum + cs.score, 0);
    const averageScore = totalScore / categories.length;
    const level = maturityLevels.find(
      (l) => averageScore >= l.scoreRange.min && averageScore <= l.scoreRange.max
    );

    setResult({
      sessionId: session.id,
      totalScore,
      averageScore,
      maturityLevel: level?.level || 1,
      categoryScores,
    });

    setMaturityLevel(level?.name || '初始级');
  };

  const getChartData = () => {
    if (!result || !result.categoryScores) return null;

    const chartData = {
      labels: categories.map((c) => c.name),
      datasets: [
        {
          label: '能力域得分',
          data: result.categoryScores.map((cs) => cs.score),
          backgroundColor: (context: any) => {
            const index = context.dataIndex;
            if (
              index < 0 ||
              index >= result.categoryScores.length ||
              !result.categoryScores[index]
            ) {
              return 'rgba(0, 0, 0, 0.1)';
            }
            const score = result.categoryScores[index].score;
            return score >= result.averageScore
              ? 'rgba(75, 192, 192, 0.4)'
              : 'rgba(255, 99, 132, 0.4)';
          },
          borderColor: (context: any) => {
            const index = context.dataIndex;
            if (
              index < 0 ||
              index >= result.categoryScores.length ||
              !result.categoryScores[index]
            ) {
              return 'rgba(0, 0, 0, 0.1)';
            }
            const score = result.categoryScores[index].score;
            return score >= result.averageScore
              ? 'rgba(75, 192, 192, 1)'
              : 'rgba(255, 99, 132, 1)';
          },
          borderWidth: 2,
          pointBackgroundColor: 'rgba(255,255,255,1)',
          pointBorderColor: (context: any) => {
            const index = context.dataIndex;
            if (
              index < 0 ||
              index >= result.categoryScores.length ||
              !result.categoryScores[index]
            ) {
              return 'rgba(0, 0, 0, 0.1)';
            }
            const score = result.categoryScores[index].score;
            return score >= result.averageScore
              ? 'rgba(75, 192, 192, 1)'
              : 'rgba(255, 99, 132, 1)';
          },
          pointBorderWidth: 2,
          pointHoverBackgroundColor: 'rgba(75, 192, 192, 1)',
          pointHoverBorderColor: 'rgba(220,220,220,1)',
        },
      ],
    };

    return chartData;
  };

  const chartOptions = {
    scales: {
      r: {
        angleLines: {
          display: true,
        },
        suggestedMin: 0,
        suggestedMax: 5,
        ticks: {
          stepSize: 1,
          showLabelBackdrop: false,
          backdropColor: 'rgba(255, 255, 255, 0.75)',
          color: '#777',
        },
        pointLabels: {
          fontSize: 14,
          fontColor: '#333',
        },
      },
    },
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        callbacks: {
          label: (context: any) => {
            const label = context.label || '';
            const value = context.parsed?.r || 0;
            return `${label}: ${value.toFixed(1)}`;
          },
        },
      },
    },
  };

  // 新增函数：保存 TXT 报告到服务器
  const saveTxtReportToBackend = useCallback(
    async (currentResult: Result, currentSessionData: Session) => {
      if (!currentResult || !currentSessionData) return;

      try {
        // 从 localStorage 获取参与者信息
        const participantInfoString = localStorage.getItem('participant_info');
        let participantName = '未知姓名';
        let participantPosition = '未知职务';
        let participantOrganization = '未知单位';
        let participantContact = '未知联系方式';
        if (participantInfoString) {
          try {
            const participantInfo = JSON.parse(participantInfoString);
            participantName = participantInfo.name || '未知姓名';
            participantPosition = participantInfo.position || '未知职务';
            participantOrganization = participantInfo.company || '未知单位';
            participantContact = participantInfo.contact || '未知联系方式';
          } catch (e) {
            console.error('解析 participant_info 失败:', e);
          }
        }

        // 构建 TXT 报告内容
        let txtContent = `数字化转型成熟度评估报告\n\n`;
        txtContent += `参与者姓名: ${participantName}\n`;
        txtContent += `参与者职务: ${participantPosition}\n`;
        txtContent += `参与者单位: ${participantOrganization}\n`;
        txtContent += `参与者联系方式: ${participantContact}\n\n`;
        txtContent += `总体评估结果:\n`;
        txtContent += `成熟度等级: ${maturityLevelAssessments[maturityLevel]?.split('建议：')[0] || '暂无评估意见'}\n`;
        txtContent += `总体得分: ${currentResult.averageScore.toFixed(1)} / 5\n\n`;

        txtContent += `能力域得分:\n`;
        currentResult.categoryScores.forEach(cs => {
          const category = categories.find(c => c.id === cs.categoryId);
          txtContent += `${category?.name || '未知能力域'}: ${cs.score.toFixed(1)} / 5\n`;
        });
        txtContent += `\n`;

        txtContent += `改进建议:\n`;
        currentResult.categoryScores.forEach(cs => {
          const category = categories.find(c => c.id === cs.categoryId);
          const recommendationsList = recommendations.filter(
            (r) => r.categoryId === category?.id && r.levelId === currentResult.maturityLevel
          );
          txtContent += `${category?.name || '未知能力域'} (${cs.score.toFixed(1)} / 5):\n`;
          if (recommendationsList.length > 0) {
            recommendationsList.forEach((rec, index) => {
              txtContent += `  ${index + 1}. ${rec.content}\n`;
              if (rec.implementationGuidance) {
                txtContent += `     实施指导: ${rec.implementationGuidance}\n`;
              }
            });
          } else {
            txtContent += `  暂无针对当前成熟度等级的建议。\n`;
          }
          txtContent += `\n`;
        });

    txtContent += '用户答案:\n';
    currentSessionData.answers.forEach((answer: any, index: number) => {
      const question = questions.find(q => q.id === answer.questionId);
      const selectedOption = question?.options.find(o => o.id === answer.selectedOptionId);
      if (question && selectedOption) {
        // Find the index of the selected option to get the letter
        const optionIndex = question.options.findIndex(o => o.id === answer.selectedOptionId);
        const optionLetter = optionIndex !== -1 ? String.fromCharCode(65 + optionIndex) : ''; // 65 is ASCII for 'A'

        txtContent += `问题 ${index + 1}: ${question.description}\n`; // 使用 question.description 获取完整问题文本并添加编号
        txtContent += `答案: ${optionLetter}. ${selectedOption.description}\n\n`;
      } else {
        txtContent += `问题ID: ${answer.questionId}, 选项ID: ${answer.selectedOptionId} (未找到问题或答案文本)\n\n`;
      }
    });

        // 调用后端 API 保存 TXT
        const response = await fetch('/api/save-txt-report', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            txtData: txtContent,
            name: participantName,
            position: participantPosition,
            answers: currentSessionData.answers,
            averageScore: currentResult.averageScore,
          }),
        });

        if (!response.ok) {
          const errorData = await response.json();
          console.error('保存 TXT 报告到服务器失败:', errorData.error);
        } else {
          console.log('TXT 报告已成功保存到服务器');
        }

      } catch (error) {
        console.error('保存 TXT 报告时发生错误:', error);
      }
    },
    [maturityLevelAssessments, maturityLevel, categories, recommendations] // 添加依赖项
  );

  // 新增函数：保存 PDF 报告到服务器
  const savePdfReportToBackend = useCallback(
    async (base64Data: string, currentResult: Result, currentSessionData: Session) => {
      if (!base64Data || !currentResult || !currentSessionData) return;

      try {
        // 从 localStorage 获取参与者信息
        const participantInfoString = localStorage.getItem('participant_info');
        let participantName = '未知姓名';
        let participantPosition = '未知职务';
        if (participantInfoString) {
          try {
            const participantInfo = JSON.parse(participantInfoString);
            participantName = participantInfo.name || '未知姓名';
            participantPosition = participantInfo.position || '未知职务';
          } catch (e) {
            console.error('解析 participant_info 失败:', e);
          }
        }

        // 调用后端 API 保存 PDF
        // const pdfBase64 = imgData.split(',')[1]; // 移除此行
        console.log('PDF Base64 data length:', base64Data.length); // 添加日志
        const response = await fetch('/api/save-report', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            pdfData: base64Data, // 直接使用接收到的 base64Data
            name: participantName,
            position: participantPosition,
            // 不再发送 answers 和 averageScore 给 PDF 保存接口
          }),
        });

        if (!response.ok) {
          const errorData = await response.json();
          console.error('保存 PDF 报告到服务器失败:', errorData.error);
        } else {
          console.log('PDF 报告已成功保存到服务器');
        }

      } catch (error) {
        console.error('保存 PDF 报告时发生错误:', error);
      }
    },
    [] // 依赖项更新
  );

  // 修改 generatePDF 函数，使其在客户端下载前先保存 PDF 到后端
  const generatePDF = useCallback(
    async (bgColor: string) => {
      if (!result || !sessionData) return;

      setIsGeneratingPDF(true);

      const buttonContainer = buttonContainerRef.current;
      let buttonContainerParent: HTMLElement | null = null;
      let buttonContainerNextSibling: ChildNode | null = null;
      if (buttonContainer) {
        buttonContainerParent = buttonContainer.parentNode as HTMLElement;
        buttonContainerNextSibling = buttonContainer.nextSibling;
        buttonContainer.remove();
      }

      try {
        const element = document.getElementById('result-content');
        if (!element) return;

        const canvas = await html2canvas(element, {
          scale: 2,
          backgroundColor: bgColor,
        });
        const imgData = canvas.toDataURL('image/jpeg', 0.6); // Adjust quality (0.0 - 1.0)

        // 先保存 PDF 报告到后端，传递 imgData
        // await savePdfReportToBackend(imgData, result, sessionData); // 移除此行

        const pdf = new jsPDF('p', 'mm', 'a4');
        const pageWidth = pdf.internal.pageSize.getWidth();
        const pageHeight = pdf.internal.pageSize.getHeight();

        const margin = 10;

        const availableWidth = pageWidth - 2 * margin;
        const availableHeight = pageHeight - 2 * margin;

        let imgWidth = availableWidth;
        let imgHeight = (canvas.height * imgWidth) / canvas.width;

        if (imgHeight > availableHeight) {
          imgHeight = availableHeight;
          imgWidth = (canvas.width * imgHeight) / canvas.height;
        }

        // 计算需要的页数
        const totalPages = Math.ceil(imgHeight / availableHeight);

        // 处理多页情况
        if (totalPages <= 1) {
          // 单页情况，直接添加整个图像
          pdf.addImage(imgData, 'PNG', (pageWidth - imgWidth) / 2, margin, imgWidth, imgHeight);
        } else {
          // 多页情况，分页添加图像的不同部分
          let sourceY = 0;
          let destY = margin;
          let remainingHeight = canvas.height;

          // 计算每页实际显示的高度（按比例）
          const pageDisplayHeight = availableHeight;
          const pageSourceHeight = (canvas.height * pageDisplayHeight) / imgHeight;

          for (let i = 0; i < totalPages; i++) {
            // 当前页要显示的源图像高度（不超过剩余高度）
            const currentPageSourceHeight = Math.min(pageSourceHeight, remainingHeight);
            // 当前页要显示的目标高度（按比例）
            const currentPageDisplayHeight = (currentPageSourceHeight * imgHeight) / canvas.height; // 修正此处，使用 canvas.height

            // 添加当前页的图像部分
            pdf.addImage({
              imageData: imgData,
              format: 'PNG',
              x: (pageWidth - imgWidth) / 2,
              y: destY,
              width: imgWidth,
              height: currentPageDisplayHeight,
              alias: undefined,
              compression: 'FAST',
              rotation: 0
            });

            // 设置裁剪区域（通过计算源图像的比例）
            // 注意：由于TypeScript类型限制，我们使用对象形式传递参数

            // 更新剩余高度和源图像位置
            remainingHeight -= currentPageSourceHeight;
            sourceY += currentPageSourceHeight;

            // 如果还有下一页，添加新页面
            if (i < totalPages - 1) {
              pdf.addPage();
              destY = margin;
            }
          }
        }

        // 获取 PDF 的 Base64 数据
        const pdfDataUri = pdf.output('datauristring');
        const pdfBase64 = pdfDataUri.split(',')[1];

        // 保存 PDF 报告到后端，传递 PDF Base64 数据
        await savePdfReportToBackend(pdfBase64, result, sessionData);

        // 客户端下载 PDF
        pdf.save('数字化转型成熟度评估报告.pdf');

      } catch (error) {
        console.error('生成 PDF 报告时发生错误:', error);
        toast({
          title: '生成 PDF 报告失败', // 添加错误提示
          description: '请稍后重试或联系管理员。',
          status: 'error',
          duration: 5000,
          isClosable: true,
        });
      } finally {
        if (buttonContainerParent && buttonContainer) {
          if (buttonContainerNextSibling) {
            buttonContainerParent.insertBefore(buttonContainer, buttonContainerNextSibling);
          } else {
            buttonContainerParent.appendChild(buttonContainer);
          }
        }
        setIsGeneratingPDF(false);
      }
    },
    [result, sessionData, buttonContainerRef, setIsGeneratingPDF, savePdfReportToBackend, toast] // 添加 toast 依赖项
  );

  // 新增 useEffect 钩子，在 result 和 sessionData 状态更新后自动保存 TXT 报告
  useEffect(() => {
    if (result && sessionData) {
      // 确保在客户端环境运行
      if (typeof window !== 'undefined') {
        saveTxtReportToBackend(result, sessionData);
      }
    }
  }, [result, sessionData, saveTxtReportToBackend]); // 依赖 result, sessionData 和 saveTxtReportToBackend

  const getStrengthsAndWeaknesses = () => {
    if (!result) return { strengths: [], weaknesses: [] };

    const sortedScores = [...result.categoryScores].sort((a, b) => b.score - a.score);
    const strengths = sortedScores
      .slice(0, 2)
      .map((cs) => categories.find((c) => c.id === cs.categoryId)?.name || '');
    const weaknesses = sortedScores
      .slice(-2)
      .map((cs) => categories.find((c) => c.id === cs.categoryId)?.name || '');

    return { strengths, weaknesses };
  };

  if (!result) return null;

  const { strengths, weaknesses } = getStrengthsAndWeaknesses();

  const progressValue = (result.averageScore / 5) * 100;

  // 获取整合后的评估意见和建议
  const assessment = maturityLevelAssessments[maturityLevel] || '暂无评估意见和建议';

  return (
    <Box minH="100vh" py={8} bg="gray.50" color={textColor}>
      <Container maxW="container.lg">
        <VStack spacing={8} align="stretch" id="result-content">
          <Heading as="h1" size="xl" textAlign="center" color={headingColor}>
            数字化转型成熟度评估报告
          </Heading>

          <Box bg={boxBg} p={6} borderRadius="lg" shadow="md">
            <VStack spacing={4} align="stretch">
              <Heading as="h2" size="lg" color={headingColor}>
                总体评估结果
              </Heading>
              <Box fontSize="xl">
                成熟度等级：<Text fontWeight="bold">{maturityLevel}</Text>
              </Box>
              <Text fontSize="lg">
                总体得分：{result.averageScore.toFixed(1)} / 5
              </Text>
              <Progress value={progressValue} colorScheme="green" size="lg" borderRadius="md" />
              <Text fontSize="sm" textAlign="right">
                {progressValue.toFixed(1)}% 完成
              </Text>
              {/* 添加整合后的评估意见和建议 */}
              <Text mt={2} fontSize="md" color="gray.600" whiteSpace="pre-wrap">
                {assessment}
              </Text>
            </VStack>
          </Box>

          <Grid templateColumns={['1fr', '1fr', '1fr 1fr']} gap={6}>
            <GridItem>
              <Box bg={boxBg} p={6} borderRadius="lg" shadow="md" h="full">
                <Heading as="h3" size="md" mb={4} color={headingColor}>
                  能力域得分分布
                </Heading>
                <Box h="300px">
                  {getChartData() && <Radar data={getChartData()!} options={chartOptions as any} />}
                </Box>
                <Text mt={2} fontSize="sm" color="green.600">
                  优势领域：{strengths.join('、')}
                </Text>
                <Text mt={2} fontSize="sm" color="red.600">
                  待改进领域：{weaknesses.join('、')}
                </Text>
              </Box>
            </GridItem>

            <GridItem>
              <Box bg={boxBg} p={6} borderRadius="lg" shadow="md" h="full">
                <Heading as="h3" size="md" mb={4} color={headingColor}>
                  改进建议
                </Heading>
                <Accordion allowMultiple defaultIndex={[]}>
                  {result.categoryScores.map((cs) => {
                    const category = categories.find((c) => c.id === cs.categoryId);
                    const recommendationsList = recommendations.filter(
                      (r) => r.categoryId === category?.id && r.levelId === result.maturityLevel
                    );
                    return (
                      <AccordionItem key={cs.categoryId}>
                        <h2>
                          <AccordionButton>
                            <Box
                              as="span"
                              flex="1"
                              textAlign="left"
                              fontWeight="bold"
                              color={headingColor}
                            >
                              {category?.name}：{cs.score.toFixed(1)} / 5
                            </Box>
                            <AccordionIcon />
                          </AccordionButton>
                        </h2>
                        <AccordionPanel pb={4}>
                          {recommendationsList.map((rec, index) => (
                            <Box
                              key={index}
                              mb={4}
                              border="1px"
                              borderColor="gray.200"
                              borderRadius="md"
                              p={3}
                            >
                              <Text fontSize="md" fontWeight="bold" color={accentColor} mb={1}>
                                {recommendationsList.length > 1
                                  ? `改进建议 ${index + 1}:`
                                  : '改进建议:'}
                              </Text>
                              <Text color="gray.600" whiteSpace="pre-wrap" ml={2}>
                                {rec.content}
                              </Text>
                              {rec.implementationGuidance && (
                                <Box mt={2} p={2} bg="gray.100" borderRadius="md">
                                  <Text
                                    color="green.600"
                                    fontStyle="italic"
                                    fontWeight="bold"
                                    mb={1}
                                  >
                                    实施指导:
                                  </Text>
                                  <Text color="gray.700" whiteSpace="pre-wrap" ml={2}>
                                    {rec.implementationGuidance}
                                  </Text>
                                </Box>
                              )}
                            </Box>
                          ))}
                        </AccordionPanel>
                      </AccordionItem>
                    );
                  })}
                </Accordion>
              </Box>
            </GridItem>
          </Grid>

          <Box display="flex" justifyContent="center" gap={4} ref={buttonContainerRef}>
            <Button onClick={() => router.push('/')} variant="outline">
              返回首页
            </Button>
            <Button
              onClick={() => generatePDF(backgroundColor)}
              colorScheme="blue"
              isLoading={isGeneratingPDF}
            >
              导出PDF报告
            </Button>
          </Box>
        </VStack>
      </Container>
    </Box>
  );
}
