import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export async function POST(request: Request) {
  try {
    const data = await request.json();
    const { pdfData, name, position } = data; // 只接收 PDF 相关数据

    if (!pdfData || !name || !position) {
      return NextResponse.json({ error: '缺少必要的 PDF 数据或参与者信息' }, { status: 400 });
    }

    // 解码 Base64 PDF 数据
    console.log('Received PDF Base64 data length:', pdfData.length); // 添加日志
    const pdfBuffer = Buffer.from(pdfData, 'base64');

    // 构建文件名
    const sanitizedName = name.replace(/[^a-zA-Z0-9_一-龥]/g, '_'); // 简单清理文件名中的非法字符
    const sanitizedPosition = position.replace(/[^a-zA-Z0-9_一-龥]/g, '_');
    const filename = `${sanitizedName}_${sanitizedPosition}.pdf`;

    // 确保data目录存在
    const dataDir = path.join(process.cwd(), 'data');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // 保存 PDF 文件
    const filePath = path.join(dataDir, filename);
    fs.writeFileSync(filePath, pdfBuffer);

    return NextResponse.json({ success: true, filePath });
  } catch (error) {
    console.error('保存 PDF 报告出错:', error);
    return NextResponse.json({ error: '服务器内部错误' }, { status: 500 });
  }
}