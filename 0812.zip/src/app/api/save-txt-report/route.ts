import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export async function POST(request: Request) {
  try {
    const data = await request.json();
    const { txtData, name, position, answers, averageScore } = data;

    if (!txtData || !name || !position || !answers || averageScore === undefined) {
      return NextResponse.json({ error: '缺少必要的报告数据或参与者信息' }, { status: 400 });
    }

    // 构建文件名
    const sanitizedName = name.replace(/[^a-zA-Z0-9_一-龥]/g, '_'); // 简单清理文件名中的非法字符
    const sanitizedPosition = position.replace(/[^a-zA-Z0-9_一-龥]/g, '_');
    const filename = `${sanitizedName}_${sanitizedPosition}.txt`;

    // 确保data目录存在
    const dataDir = path.join(process.cwd(), 'data');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // 保存文本文件
    const filePath = path.join(dataDir, filename);
    fs.writeFileSync(filePath, txtData);

    return NextResponse.json({ success: true, filePath });
  } catch (error) {
    console.error('保存 TXT 报告出错:', error);
    return NextResponse.json({ error: '服务器内部错误' }, { status: 500 });
  }
}