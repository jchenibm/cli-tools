import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export async function POST(request: Request) {
  try {
    const data = await request.json();
    const { name, company, department, position, phone, email, timestamp, surveyResults, averageScore } = data;

    // 确保数据有效
    if (!name || !company || !department || !position || !phone || !email) {
      return NextResponse.json({ error: '缺少必要信息' }, { status: 400 });
    }

    // 处理CSV中的特殊字符，防止CSV注入
    const escapeCsvField = (field: string) => {
      // 如果字段包含逗号、双引号或换行符，则用双引号包裹并将内部的双引号替换为两个双引号
      if (field.includes(',') || field.includes('"') || field.includes('\n')) {
        return `"${field.replace(/"/g, '""')}"`;
      }
      return field;
    };

    const csvLine = `${escapeCsvField(name)},${escapeCsvField(company)},${escapeCsvField(department)},${escapeCsvField(position)},${escapeCsvField(phone)},${escapeCsvField(email)},${timestamp}\n`;

    // 确保data目录存在
    const dataDir = path.join(process.cwd(), 'data');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // 写入CSV文件
    const csvFilePath = path.join(dataDir, 'participants.csv');

    // 检查文件是否存在，如果不存在则创建并添加表头
    if (!fs.existsSync(csvFilePath)) {
      fs.writeFileSync(csvFilePath, '姓名,单位,部门,职务,手机号,邮箱,提交时间\n');
    }

    // 追加数据
    fs.appendFileSync(csvFilePath, csvLine);



    return NextResponse.json({ message: 'Participant info saved successfully' }, { status: 200 });
  } catch (error) {
    console.error('Error saving participant info:', error);
    return NextResponse.json({ message: 'Error saving participant info' }, { status: 500 });
  }
}